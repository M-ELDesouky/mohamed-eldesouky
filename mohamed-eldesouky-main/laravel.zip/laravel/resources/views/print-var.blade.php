
<p>{{ $name }}</p>
<p>{{ $age }}</p>
