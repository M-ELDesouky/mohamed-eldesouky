<?php
namespace App\Database\Models\Contract;

use App\Database\Contract\Connection;

class Model extends Connection {
    public static function find()
    {
        # code...
    }
}